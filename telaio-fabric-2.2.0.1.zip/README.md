# 2.2.0.1
fabric PDC 기능 대응에 따른 discovery interests 기능 적용.

<br><br>

## Release Note
- release note: Telaio Application Release Note v2.2.0.1.pdf
- package: telaio-fabric-2.2.0.1.jar
- doc: telaio-project-javadoc-2.2.0.1.zip
- guide: C_RnD-BLC-FW-TELAIO for Application 적용 가이드-v2.2.0.1.pdf
